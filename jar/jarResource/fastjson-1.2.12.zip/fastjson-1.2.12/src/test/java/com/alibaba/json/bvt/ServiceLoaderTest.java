package com.alibaba.json.bvt;

import junit.framework.TestCase;

import com.alibaba.fastjson.util.ServiceLoader;


public class ServiceLoaderTest extends TestCase {
    public void test_0() throws Exception {
        new ServiceLoader();
    }
}
